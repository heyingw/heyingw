
var cartItemNumber=0;
var ItemsInCart=[]


function addToCart(){
cartItemNumber+=1;
ItemsInCart.push("Original Roll");
window.alert("One item has been added to your cart!");
document.getElementById("cartItem").innerHTML= "Shopping Cart: "+ cartItemNumber;
}


function deleteItem()
{document.getElementById('itemName').innerHTML="rolls";
window.alert("You have deleted this item");
 
}

//change profile image with radio button
function changeImageTo1(){
	document.getElementById('thumbnailImage').src="./Images/rolls 1.png"
}

function changeImageTo3(){
	document.getElementById('thumbnailImage').src="./Images/Size3.jpg"
}

function changeImageTo6(){
	document.getElementById('thumbnailImage').src="./Images/Size6.jpg"
}

function changeImageTo12(){
	document.getElementById('thumbnailImage').src="./Images/Size12.jpg"
}

function changeImageToNone(){
	document.getElementById('thumbnailImage').src="./Images/rolls 1.png"
}

function changeImageToSM(){
	document.getElementById('thumbnailImage').src="./Images/SM.jpg"
}

function changeImageToVM(){
	document.getElementById('thumbnailImage').src="./Images/VM.jpg"
}

function changeImageToDC(){
	document.getElementById('thumbnailImage').src="./Images/DC.jpg"
}


 


 


  



