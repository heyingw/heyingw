
// starter code for week 5 of pui lab


function addNewList() {
    alert('hello world alert!');
    console.log('hello world console');
}

document.getElementById("one").onclick=myFunction(){}
function myFunction(){ var x = document.getElementById("thumbnailImage");
  x.src = "./rolls 6.png";
}

function myFunction2(){ var x = document.getElementById("thumbnailImage");
  x.src = "./rolls 5.png";
}

function myFunction3(){ var x = document.getElementById("thumbnailImage");
  x.src = "./rolls 4.png";
}

function myFunction4(){ var x = document.getElementById("thumbnailImage");
  x.src = "./rolls 3.png";
}

function myFunction5(){ var x = document.getElementById("thumbnailImage");
  x.src = "./rolls 2.png";
}

var cartItem=0
Function addtoCart(){
	var cartItem+=1
	 document.getElementById("cartItem").innerHTML="Shopping cart:cartItem"
}