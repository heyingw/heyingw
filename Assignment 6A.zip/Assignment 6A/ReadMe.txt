Extra page 1:
One extra product detail page--"Blackberry rolls"

Extra page 2:
Login page, which can be accessed from my account.